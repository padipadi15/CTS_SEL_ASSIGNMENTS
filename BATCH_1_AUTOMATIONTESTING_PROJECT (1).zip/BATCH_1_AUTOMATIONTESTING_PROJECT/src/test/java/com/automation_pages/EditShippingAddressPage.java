package com.automation_pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class EditShippingAddressPage {
	WebDriver driver;
	By Myaccount=By.linkText("My Account");
	By Username=By.id("username");
	By Password=By.id("password");
	By login=By.xpath("//input[@name='login']");
	By Address=By.linkText("Addresses");
	By editshipping=By.xpath("//a[@href='http://practice.automationtesting.in/my-account/edit-address/shipping']");
	By shippingfirstname=By.id("shipping_first_name");
	By shippinglastname=By.id("shipping_last_name");
	By shippingcompany=By.id("shipping_company");
	By shippingaddress1=By.id("shipping_address_1");
	By shippingaddress2=By.id("shipping_address_2");
	By shippingcity=By.id("shipping_city");
	By shippingpostcode=By.id("shipping_postcode");
	By clicksaveaddress=By.name("save_address");
	By Shipping=By.xpath("//div[@class='woocommerce-message']");
	
	public EditShippingAddressPage(WebDriver driver) 
	{
		this.driver =driver;
	}
	
	//To click on address
	public void clickAddresses() {
		driver.findElement(Address).click();
	}
	//To edit shipping address
	public void editShipping() {
		driver.findElement(editshipping).click();
	}
	//To fill shipping details
	public void fillShippingDetails() {
		driver.findElement(shippingfirstname).clear();
		driver.findElement(shippingfirstname).sendKeys("Bhargavi");
		driver.findElement(shippinglastname).clear();
		driver.findElement(shippinglastname).sendKeys("Nagalla");
		driver.findElement(shippingcompany).clear();
		driver.findElement(shippingcompany).sendKeys("cts");
		driver.findElement(shippingaddress1).clear();
		driver.findElement(shippingaddress1).sendKeys("9-249");
		driver.findElement(shippingaddress2).clear();
		driver.findElement(shippingaddress2).sendKeys("tidal");
		driver.findElement(shippingcity).clear();
		driver.findElement(shippingcity).sendKeys("Hydereabad");
		driver.findElement(shippingpostcode).clear();
		driver.findElement(shippingpostcode).sendKeys("456213");
	}
	//To save address
	public void clickSaveAddress() {
		driver.findElement(clicksaveaddress).click();
	}
	//Assert
	public void AssertShipping() {
		String a = driver.findElement(Shipping).getText();
		Assert.assertEquals("Address changed successfully.",a);
		System.out.println("Shipping saved Successfully");
	}
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("\\Screenshots\\ShippingAddress.png"));
	}
	//To close the browser window
		public void quit() {
			driver.close();
		}
}
