package com.automation_pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class automation_seeingstock_addtocart_page {
	Logger LOG = Logger.getLogger( automation_seeingstock_addtocart_page.class.getName());
	 WebDriver driver;
	By clickshop = By.xpath("//*[@id=\"menu-item-40\"]/a");
	By productclick = By.xpath("//*[@id=\"content\"]/ul/li[2]/a[1]/h3");
	By addtocart = By.xpath("//*[@id=\"product-170\"]/div[2]/form/button");
	

	
	public automation_seeingstock_addtocart_page(WebDriver driver) 
	{
		this.driver =driver;
	}

	//open product
	public void automation_openproduct() {
		driver.findElement(clickshop).click();

		driver.findElement(productclick).click();
		LOG.info("product is opened ");
	}
	
	//verify whether stock is available or not
	public void automation_stockcheck() {
		String act_stock = driver.findElement(By.xpath("//*[@id=\"product-170\"]/div[2]/p")).getText();
		String exp_stock = "out of stock";
		if(act_stock.equalsIgnoreCase(exp_stock))
		{
			System.out.println("stock is not available");
		}
		else {
			System.out.println("stock is  available");
			driver.findElement(addtocart).click();

		}
		LOG.info("product is in stock");
	}
	
	

}
