package com.automation_pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class automation_login_page {
	Logger LOG = Logger.getLogger( automation_login_page.class.getName());
	 WebDriver driver;
	By username1 = By.id("username");
	By password1 = By.id("password");
	By Loginbutton = By.xpath("/html/body/div[1]/div[2]/div/div/div/div/div[1]/div/div[1]/form/p[3]/input[3]");
	

	
	public automation_login_page(WebDriver driver) 
	{
		this.driver =driver;
	}

	//Enter username
	public void automation_username(String username) {
		driver.findElement(By.xpath("//*[@id=\"menu-item-50\"]/a")).click();

		driver.findElement(username1).sendKeys(username);
		LOG.info("Entered Name in the UserName field ");
	}
	
	//Entering the password
	public void automation_password(String password) {
		driver.findElement(password1).sendKeys(password);
		LOG.info("Enterd password in tbe Password field");
	}
	
	//click the login button
	public void automation_loginbtn() {
		driver.findElement(Loginbutton).click();
		LOG.info("Login Button is Clicked");
	}
	


}
